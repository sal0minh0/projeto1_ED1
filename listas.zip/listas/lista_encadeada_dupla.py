class No:
    """Classe nó nessa lista"""
    def __init__(self, valor):
        self.valor = valor
        self.anterior = None
        self.prox = None
        
class ListaEncadeadaDupla:
    """Classe da lista dupla"""
    def __init__(self):
        self.cabeca = None
        self.cauda = None

    def verificar_lista_vazia(self):
        """Será que essa lista está vazia?"""
        return self.cabeca is None

    def inserir(self, valor):
        """Inserir no final da lista"""
        novo_no = No(valor)
        if self.verificar_lista_vazia():
            self.cabeca = self.cauda = novo_no
        else:
            self.cauda.prox = novo_no
            novo_no.anterior = self.cauda
            self.cauda = novo_no

    def remover(self, valor):
        """Remover um nó da lista"""
        if self.verificar_lista_vazia():
            print("A lista está vazia, nada para remover.")
            return
        atual = self.cabeca
        while atual:
            if atual.valor == valor:
                if atual.anterior:
                    atual.anterior.prox = atual.prox
                else:
                    self.cabeca = atual.prox

                if atual.prox:
                    atual.prox.anterior = atual.anterior
                else:
                    self.cauda = atual.anterior
                return
            atual = atual.prox
        print("Valor não encontrado na lista.")

    def buscar(self, valor):
        """Busca valores na lista"""
        atual = self.cabeca
        while atual:
            if atual.valor == valor:
                return atual
            atual = atual.prox
        return None

    def atualizar(self, valor_atual, novo_valor):
        """Atualizar um valor na lista"""
        no_encontrado = self.buscar(valor_atual)
        if no_encontrado:
            no_encontrado.valor = novo_valor
        else:
            print("Valor não encontrado na lista para atualização.")

    def imprimir(self):
        """Imprime a lista até o final"""
        if self.verificar_lista_vazia():
            print("A lista está vazia.")
            return
        atual = self.cabeca
        while atual:
            print(atual.valor, end = " - " if atual.prox else "\n")
            atual = atual.prox
            
            
            def trocar_true_false_sim_nao(valor):
                return "Sim" if valor else "Não"
            resposta = True
            resposta = False
            

# Exemplo de uso da lista encadeada dupla
l = ListaEncadeadaDupla()

# Inserindo valores
l.inserir(10)
l.inserir(20)
l.inserir(30)
print("")

# Imprimindo a lista
print("Lista:")
l.imprimir()
print("")

# Atualizando um valor
l.atualizar(20, 25)
print("Lista após atualização:")
l.imprimir()
print("")

# ->>>>>>Colocar um print ou deixar assim?
# Buscando um valor
buscar_no = l.buscar(25)
if buscar_no:
    print(f"O Valor {buscar_no.valor} encontrado.")
else:
    print("O Valor não encontrado.")
print("")

# Removendo um valor
l.remover(25)
print("Lista após remoção:")
l.imprimir()
print("")

# Verificando se a lista está vazia
print("A lista está vazia?", "Sim" if l.verificar_lista_vazia() else "Não")
